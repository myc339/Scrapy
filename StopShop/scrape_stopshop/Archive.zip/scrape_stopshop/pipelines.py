# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import json
import codecs
# import pymongo 
# from scrapy_dynamodb import DynamoDbPipeline
import boto3
from scrape_stopshop.items import ScrapeStopshopItem
class MongoPipeline(object):

    collection_name = 'StopShop'

    #, mongo_uri, mongo_db
    # def __init__(self):
    #     self.file = codecs.open('result.json', 'w', encoding='utf-8')
        
       
        # self.mongo_uri = mongo_uri
        # self.mongo_db = mongo_db

    # @classmethod
    # def from_crawler(cls, crawler):
    #     return cls(
    #        mongo_uri=crawler.settings.get('MONGO_URI'),
    #        mongo_db=crawler.settings.get('MONGO_DATABASE')
    #     )

    # def open_spider(self, spider):
        
        # self.client = pymongo.MongoClient(self.mongo_uri)
    #     self.db = self.client[self.mongo_db]

    # def close_spider(self, spider):
    #     self.file.close()
        # self.client.close()
    def process_item(self, item, spider):
        dynamodb = boto3.resource('dynamodb',region_name="us-east-1")
        table = dynamodb.Table('stopshop')
        print("saving",item['Item'])
        table.put_item(
            Item={
                'storeCode':item["storeCode"],
                'ItemId':item["ItemId"],
                'category': item['category'],
                'Item':item['Item'],
                'ImageSrc':item['ImageSrc'],
                'PriceTag': item['PriceTag'],
                'validity':item['validity'],
                'itemDisclaimerText':item['item_disclaimer_text'],
                'itemDescription': item['item_description'],
                'SalesStory':item['SalesStory'], 
                'Coupon':item['Coupon'],
                'link':item['link'] 
            }
        )
        # line = json.dumps(dict(item), ensure_ascii=False) + ",\n"
        # self.file.write(line)
        return item
